

options("scipen" = 100) # 숫자의 지수표현을 숫자표현으로 바꿔준다. 
#이를 쓰는 이유는 표현되는 숫자 비교를 좀 더 쉽게 하기 위함이다. 

getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}
#mode를 구하는 함수이다. R에는 mode구하는 built_in 함수가 없다. 


install.packages("readxl")  #엑셀 불러오는 패키지이다. 
library(readxl)
#데이터 불러오기 ##
positionandteam2018=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_선수_2018.xlsm")
taza2018=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_타자 기본_2018.xlsm")
gong2018=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_HTS_2018.xls")

taza2019=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_타자 기본_2019.xls")
gong2019=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_HTS_2019.xls")

taza2020=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_타자 기본_2020.xls")
gong2020=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_HTS_2020.xls")


taza2021=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_타자 기본_2021.xls")
gong2021=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_HTS_2021.xls")
##-----------------------------------------------------------------------------------------------
library(rjags)

#선수별 공의 (각도,속도) 정의 2021년, 2020년 데이터만 사용. 


# 양의지 76232

yang2021=data.frame(cbind(gong2021[gong2021$PCODE==76232,]$HIT_ANG_VER,gong2021[gong2021$PCODE==76232,]$HIT_VEL))
yang2020=data.frame(cbind(gong2020[gong2020$PCODE==76232,]$HIT_ANG_VER,gong2020[gong2020$PCODE==76232,]$HIT_VEL))
yang=data.frame(rbind(yang2020,yang2021))
colnames(yang)=c("angle","velocity")
#taza2021[taza2021$PCODE==76232,]$SLG #선수들의 장타율을 구하는 코드 
#taza2021[taza2021$PCODE==76232,]$AB+taza2020[taza2020$PCODE==76232,]$AB
#taza2020[taza2020$PCODE==76232,]$SLG
#gong2021[gong2021$PCODE==76232,]

#강백호 68050
backho2021=data.frame(cbind(gong2021[gong2021$PCODE==68050,]$HIT_ANG_VER,gong2021[gong2021$PCODE==68050,]$HIT_VEL))
backho2020=data.frame(cbind(gong2020[gong2020$PCODE==68050,]$HIT_ANG_VER,gong2020[gong2020$PCODE==68050,]$HIT_VEL))
backho=data.frame(rbind(backho2020,backho2021))
colnames(backho)=c("angle","velocity")
#taza2021[taza2021$PCODE==68050,]$SLG
#taza2020[taza2020$PCODE==68050,]$SLG
#taza2021[taza2021$PCODE==68050,]$AB+taza2020[taza2020$PCODE==68050,]$AB

#표준화 
backho$angle=(backho$angle-mean(backho$angle))/(var(backho$angle)^(1/2))
backho$velocity=(backho$velocity-mean(backho$velocity))/(var(backho$velocity)^(1/2))


#박건우 79215
gunwoo2021=data.frame(cbind(gong2021[gong2021$PCODE==79215,]$HIT_ANG_VER,gong2021[gong2021$PCODE==79215,]$HIT_VEL))
gunwoo2020=data.frame(cbind(gong2020[gong2020$PCODE==79215,]$HIT_ANG_VER,gong2020[gong2020$PCODE==79215,]$HIT_VEL))
gunwoo=data.frame(rbind(gunwoo2020,gunwoo2021))
colnames(gunwoo)=c("angle","velocity")
#taza2021[taza2021$PCODE==79215,]$SLG
#taza2020[taza2020$PCODE==79215,]$SLG
#taza2021[taza2021$PCODE==79215,]$AB+taza2020[taza2020$PCODE==79215,]$AB

#최정 75847
choijung2021=data.frame(cbind(gong2021[gong2021$PCODE==75847,]$HIT_ANG_VER,gong2021[gong2021$PCODE==75847,]$HIT_VEL))
choijung2020=data.frame(cbind(gong2020[gong2020$PCODE==75847,]$HIT_ANG_VER,gong2020[gong2020$PCODE==75847,]$HIT_VEL))
choigung=data.frame(rbind(choijung2020,choijung2021))
colnames(choigung)=c("angle","velocity")
#taza2021[taza2021$PCODE==75847,]$SLG #0.598
#taza2020[taza2020$PCODE==75847,]$SLG #0.538

#이정후 67341 
leejunghu2021=data.frame(cbind(gong2021[gong2021$PCODE==67341 ,]$HIT_ANG_VER,gong2021[gong2021$PCODE== 67341 ,]$HIT_VEL))
leejunghu2020=data.frame(cbind(gong2020[gong2020$PCODE==67341 ,]$HIT_ANG_VER,gong2020[gong2020$PCODE== 67341 ,]$HIT_VEL))
leejunghu=data.frame(rbind(leejunghu2020,leejunghu2021))
colnames(leejunghu)=c("angle","velocity")
#taza2021[taza2021$PCODE==67341,]$SLG #0.503
#taza2020[taza2020$PCODE==67341,]$SLG #0.524

#채은성 79192
chaensung2021=data.frame(cbind(gong2021[gong2021$PCODE==79192 ,]$HIT_ANG_VER,gong2021[gong2021$PCODE== 79192 ,]$HIT_VEL))
chaensung2020=data.frame(cbind(gong2020[gong2020$PCODE==79192 ,]$HIT_ANG_VER,gong2020[gong2020$PCODE== 79192 ,]$HIT_VEL))
chaensung=data.frame(rbind(chaensung2020,chaensung2021))
colnames(chaensung)=c("angle","velocity")
#taza2021[taza2021$PCODE==79192,]$SLG #0.533
#taza2020[taza2020$PCODE==79192,]$SLG #0.452

#김재환 78224
kimjaehwan2021=data.frame(cbind(gong2021[gong2021$PCODE==78224 ,]$HIT_ANG_VER,gong2021[gong2021$PCODE== 78224 ,]$HIT_VEL))
kimjaehwan2020=data.frame(cbind(gong2020[gong2020$PCODE==78224 ,]$HIT_ANG_VER,gong2020[gong2020$PCODE== 78224 ,]$HIT_VEL))
kimjaehwan=data.frame(rbind(kimjaehwan2020,kimjaehwan2021))
colnames(kimjaehwan)=c("angle","velocity")
#taza2021[taza2021$PCODE==78224,]$SLG #0.508
#taza2020[taza2020$PCODE==78224,]$SLG #0.494

#전준우 78513
junjunwoo2021=data.frame(cbind(gong2021[gong2021$PCODE==78513,]$HIT_ANG_VER,gong2021[gong2021$PCODE== 78513 ,]$HIT_VEL))
junjunwoo2020=data.frame(cbind(gong2020[gong2020$PCODE==78513 ,]$HIT_ANG_VER,gong2020[gong2020$PCODE== 78513 ,]$HIT_VEL))
junjunwoo=data.frame(rbind(junjunwoo2020,junjunwoo2021))
colnames(junjunwoo)=c("angle","velocity")
#taza2021[taza2021$PCODE==78513,]$SLG #0.447
#taza2020[taza2020$PCODE==78513,]$SLG #0.482


#김현수 76290
kimhyensu2021=data.frame(cbind(gong2021[gong2021$PCODE==76290,]$HIT_ANG_VER,gong2021[gong2021$PCODE== 76290 ,]$HIT_VEL))
kimhyensu2020=data.frame(cbind(gong2020[gong2020$PCODE==76290 ,]$HIT_ANG_VER,gong2020[gong2020$PCODE== 76290 ,]$HIT_VEL))
kimhyensu=data.frame(rbind(kimhyensu2020,kimhyensu2021))
colnames(kimhyensu)=c("angle","velocity")
#taza2021[taza2021$PCODE==76290,]$SLG #0.468
#taza2020[taza2020$PCODE==76290,]$SLG #0.523

#로맥 67872
romack2021=data.frame(cbind(gong2021[gong2021$PCODE==67872,]$HIT_ANG_VER,gong2021[gong2021$PCODE== 67872 ,]$HIT_VEL))
romack2020=data.frame(cbind(gong2020[gong2020$PCODE==67872 ,]$HIT_ANG_VER,gong2020[gong2020$PCODE== 67872 ,]$HIT_VEL))
romack=data.frame(rbind(romack2020,romack2021))
colnames(romack)=c("angle","velocity")
#taza2021[taza2021$PCODE==67872,]$SLG #0.459
#taza2020[taza2020$PCODE==67872,]$SLG #0.546

#--------------------------------------------------------------------------------------------------------------------------------

#공의 (각도,속도)는 다변량 정규분포를 따른다고 가정한다. 
#(각도, 속도)의 다변량 정규분포의 모수들의 사후분포를 만들기 위해서는 모수에 대한 사전분포를 명시해야한다.
#공분산행렬은 noninformative한 걸 사용한다. ex) diag(2)
#각도와 속도 각각의 평균만이 남는데, 데이터의 평균을 사용한다. 
mean(finalyanggong$angle)#22.76711  
mean(finalyanggong$velocity)#138.0406
source("baseball.R")
mcmcsamplesyang=genMCMC( data=finalyanggong ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 )#사전분포 바꿀 것 
#baseball.R에 들어가서 각 평균에 대한 사전분포를 아래 값들로 바꿔야 한다. 

yangbadgongdata=badgongdata[badgongdata$PCODE==76232,]
yangbadgongdata=data.frame(cbind(yangbadgongdata$HIT_ANG_VER,yangbadgongdata$HIT_VEL))
colnames(yangbadgongdata)=c("angle",'velocity')
mean(yangbadgongdata$angle)# 28.35667
mean(yangbadgongdata$velocity)#133.2932
source("baseball.R")
mcmcsamplesyangbadgong=genMCMC( data=yangbadgongdata ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 
plotMCMC(codaSamples=mcmcsamplesyangbadgong , data=yangbadgongdata) 

mean(finalbackhogong$angle)
mean(finalbackhogong$velocity)
source("baseball.R")
mcmcsamplesbackho=genMCMC( data=finalbackhogong ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 

backhobadgongdata=badgongdata[badgongdata$PCODE==68050,]
backhobadgongdata=data.frame(cbind(backhobadgongdata$HIT_ANG_VER,backhobadgongdata$HIT_VEL))
colnames(backhobadgongdata)=c("angle",'velocity')
mean(backhobadgongdata$angle)# 22.44831
mean(backhobadgongdata$velocity)#132.3824
source("baseball.R")
mcmcsamplesbackhobadgong=genMCMC( data=backhobadgongdata ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 
plotMCMC(codaSamples=mcmcsamplesbackhobadgong , data=backhobadgongdata) 




mean(finalgunwoogong$angle) #17.5
mean(finalgunwoogong$velocity) #144.56
source("baseball.R")
mcmcsamplesgunwoo=genMCMC( data=finalgunwoogong ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 

gunwoobadgongdata=badgongdata[badgongdata$PCODE==79215,]
gunwoobadgongdata=data.frame(cbind(gunwoobadgongdata$HIT_ANG_VER,gunwoobadgongdata$HIT_VEL))
colnames(gunwoobadgongdata)=c("angle",'velocity')
mean(gunwoobadgongdata$angle)# 22.13068
mean(gunwoobadgongdata$velocity)#133,9891

source("baseball.R")
mcmcsamplesgunwoobadgong=genMCMC( data=gunwoobadgongdata ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 
plotMCMC(codaSamples=mcmcsamplesgunwoobadgong , data=gunwoobadgongdata) 



# 75847
mean(finalchoigunggong$angle)#17.90858
mean(finalchoigunggong$velocity) #136.4017
source("baseball.R")
mcmcsampleschoigung=genMCMC( data=choigung ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 

choigungbadgongdata=badgongdata[badgongdata$PCODE==75847,]
choigungbadgongdata=data.frame(cbind(choigungbadgongdata$HIT_ANG_VER,choigungbadgongdata$HIT_VEL))
colnames(choigungbadgongdata)=c("angle",'velocity')
mean(choigungbadgongdata$angle)#32.36759
mean(choigungbadgongdata$velocity)#134.6423

source("baseball.R")
mcmcsampleschoigungbadgong=genMCMC( data=choigungbadgongdata ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 
plotMCMC(codaSamples=mcmcsampleschoigungbadgong , data=choigungbadgongdata) 






mean(finalleejunghugong$angle)
mean(finalleejunghugong$velocity) 
source("baseball.R")
mcmcsamplesleejunghu=genMCMC( data=finalleejunghugong,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 

leejunghubadgongdata=badgongdata[badgongdata$PCODE==67341,]
leejunghubadgongdata=data.frame(cbind(leejunghubadgongdata$HIT_ANG_VER,leejunghubadgongdata$HIT_VEL))
colnames(leejunghubadgongdata)=c("angle",'velocity')
mean(leejunghubadgongdata$angle)#14.32014
mean(leejunghubadgongdata$velocity)#135.9552

source("baseball.R")
mcmcsamplesleejunghubadgong =genMCMC( data=leejunghubadgongdata ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 
plotMCMC(codaSamples=mcmcsamplesleejunghubadgong , data=leejunghubadgongdata) 




mean(finalchaensunggong$angle)#19.15315
mean(finalchaensunggong$velocity) #139.4891
source("baseball.R")
mcmcsampleschaensung=genMCMC( data=finalchaensunggong,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 

chaensungbadgongdata=badgongdata[badgongdata$PCODE==79192,]
chaensungbadgongdata=data.frame(cbind(chaensungbadgongdata$HIT_ANG_VER,chaensungbadgongdata$HIT_VEL))
colnames(chaensungbadgongdata)=c("angle",'velocity')
mean(chaensungbadgongdata$angle)#23.58673
mean(chaensungbadgongdata$velocity)# 131.2098

source("baseball.R")
mcmcsampleschaensungbadgong=genMCMC( data=chaensungbadgongdata ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 
plotMCMC(codaSamples=mcmcsampleschaensungbadgong , data=chaensungbadgongdata) 





mean(finalkimjaehwangong$angle)
mean(finalkimjaehwangong$velocity)
source("baseball.R")
mcmcsampleskimjaehwan=genMCMC( data=finalkimjaehwangong,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 

kimjaehwanbadgongdata=badgongdata[badgongdata$PCODE== 78224,]
kimjaehwanbadgongdata=data.frame(cbind(kimjaehwanbadgongdata$HIT_ANG_VER,kimjaehwanbadgongdata$HIT_VEL))
colnames(kimjaehwanbadgongdata)=c("angle",'velocity')
mean(kimjaehwanbadgongdata$angle)
mean(kimjaehwanbadgongdata$velocity)

source("baseball.R")
mcmcsampleskimjaehwanbadgong=genMCMC( data=kimjaehwanbadgongdata ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 
plotMCMC(codaSamples=mcmcsampleskimjaehwanbadgong , data=kimjaehwanbadgongdata) 




junjunwoo
mean(finaljunjunwoogong$angle)
mean(finaljunjunwoogong$velocity)
source("baseball.R")
mcmcsamplesjunjunwoo=genMCMC( data=finaljunjunwoogong,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 


junjunwoobadgongdata=badgongdata[badgongdata$PCODE==78513,]
junjunwoobadgongdata=data.frame(cbind(junjunwoobadgongdata$HIT_ANG_VER,junjunwoobadgongdata$HIT_VEL))
colnames(junjunwoobadgongdata)=c("angle",'velocity')
mean(junjunwoobadgongdata$angle)
mean(junjunwoobadgongdata$velocity)

source("baseball.R")
mcmcsamplesjunjunwoobadgong=genMCMC( data=junjunwoobadgongdata ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 
plotMCMC(codaSamples=mcmcsamplesjunjunwoobadgong , data=junjunwoobadgongdata) 





kimhyensu
mean(finalkimhyensugong$angle)
mean(finalkimhyensugong$velocity) 
source("baseball.R")
mcmcsampleskimhyensu=genMCMC( data=finalkimhyensugong,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 


kimhyensubadgongdata=badgongdata[badgongdata$PCODE==76290,]
kimhyensubadgongdata=data.frame(cbind(kimhyensubadgongdata$HIT_ANG_VER,kimhyensubadgongdata$HIT_VEL))
colnames(kimhyensubadgongdata)=c("angle",'velocity')
mean(kimhyensubadgongdata$angle)#23.58673
mean(kimhyensubadgongdata$velocity)# 131.2098

source("baseball.R")
mcmcsampleskimhyensubadgong=genMCMC( data=kimhyensubadgongdata ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 
plotMCMC(codaSamples=mcmcsampleskimhyensubadgong , data=kimhyensubadgongdata) 





romack
mean(finalromackgong$angle)# 22.56242
mean(finalromackgong$velocity) #140.5121
source("baseball.R")
mcmcsamplesromack=genMCMC( data=finalromackgong,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 


romackbadgongdata=badgongdata[badgongdata$PCODE==67872,]
romackbadgongdata=data.frame(cbind(romackbadgongdata$HIT_ANG_VER,romackbadgongdata$HIT_VEL))
colnames(romackbadgongdata)=c("angle",'velocity')
mean(romackbadgongdata$angle)
mean(romackbadgongdata$velocity)

source("baseball.R")
mcmcsamplesromackbadgong=genMCMC( data=romackbadgongdata ,numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) #사전분포 반드시 바꿀 것 
plotMCMC(codaSamples=mcmcsamplesromackbadgong , data=romackbadgongdata) 




plotMCMC(codaSamples=mcmcsamplesyang , data=yang)
plotMCMC(codaSamples=mcmcsamplesbackho , data=backho) 
plotMCMC(codaSamples=mcmcsamplesgunwoo , data=gunwoo) 
plotMCMC(codaSamples=mcmcsampleschoigung , data=choigung) 
plotMCMC(codaSamples=mcmcsamplesleejunghu , data=finalleejunghugong) 
plotMCMC(codaSamples=mcmcsampleschaensung , data=chaensung) 
plotMCMC(codaSamples=mcmcsampleskimjaehwan , data=finalkimjaehwangong) 
plotMCMC(codaSamples=mcmcsamplesjunjunwoo , data=finaljunjunwoogong) 
plotMCMC(codaSamples=mcmcsampleskimhyensu , data=finalkimhyensugong) 
plotMCMC(codaSamples=mcmcsamplesromack , data=finalromackgong) 


#그려서 모수들의 사후분포를 확인하기. 

#모수들의 사후분포를 확인했다면, 각각의 최빈값들을 이변량 정규분포의 모수값에 넣는다. 
#선수들마다 다르다는 걸 확인하라. 
library(mvtnorm)
sigmayang <- matrix(c(552,-163,-163,337), ncol=2)
yangsamples<- rmvnorm(n=2000 ,mean=c(23.2,139), sigma=sigmayang)
yangsamples=data.frame(yangsamples)
colnames(yangsamples)=c("angle","velocity")
#yangsamples=yangsamples[yangsamples$velocity>=40&yangsamples$velocity<=180,] #이상값 삭제 이상값의 기준은 기존 데이터의 범위이다. 
#yangsamples=yangsamples[yangsamples$angle>=-50&yangsamples$angle<=90,]
colMeans(yangsamples)
var(yangsamples)

library(mvtnorm)
sigmabadyang <- matrix(c(705,-159,-159,334), ncol=2)
yangbadsamples<- rmvnorm(n=34 ,mean=c(28.3,133), sigma=sigmabadyang)
yangbadsamples=data.frame(yangbadsamples)
colnames(yangbadsamples)=c("angle","velocity")
colMeans(yangbadsamples)
var(yangbadsamples)
yangbadsamples['HIT_RESULT_NUM']=1



sigmabackho=matrix(c(537,-126,-126,488), ncol=2)
backhosamples<- rmvnorm(n=2000, mean=c(17.6,139), sigma=sigmabackho) 
backhosamples=data.frame(backhosamples)
colnames(backhosamples)=c("angle","velocity")
colMeans(backhosamples)
var(backhosamples)

library(mvtnorm)
sigmabadbackho <- matrix(c(855,-143,-143,490), ncol=2)
backhobadsamples<- rmvnorm(n=61 ,mean=c(22.5,132), sigma=sigmabadbackho)
backhobadsamples=data.frame(backhobadsamples)
colnames(backhobadsamples)=c("angle","velocity")
colMeans(backhobadsamples)
var(backhobadsamples)
backhobadsamples['HIT_RESULT_NUM']=1


sigmagunwoo=matrix(c(650,-117,-117,404), ncol=2)
gunwoosamples<- rmvnorm(n=2000, mean=c(18,136), sigma=sigmagunwoo)
gunwoosamples=data.frame(gunwoosamples)
colnames(gunwoosamples)=c("angle","velocity")
colMeans(gunwoosamples)
var(gunwoosamples)

library(mvtnorm)
sigmabadgunwoo <- matrix(c(734,-73.5,-73.5,359), ncol=2)
gunwoobadsamples<- rmvnorm(n=41 ,mean=c(22.1,134), sigma=sigmabadgunwoo)
gunwoobadsamples=data.frame(gunwoobadsamples)
colnames(gunwoobadsamples)=c("angle","velocity")
colMeans(gunwoobadsamples)
var(gunwoobadsamples)
gunwoobadsamples['HIT_RESULT_NUM']=1


sigmachoigung=matrix(c(676,-92.6,-92.6,338), ncol=2)
choigungsamples<- rmvnorm(n=2000, mean=c(22.2,138), sigma=sigmachoigung)
choigungsamples=data.frame(choigungsamples)
colnames(choigungsamples)=c("angle","velocity")
colMeans(choigungsamples)
var(choigungsamples)

library(mvtnorm)
sigmabadchoigung<- matrix(c(676,-92.6,-92.6,338), ncol=2)
choigungbadsamples<- rmvnorm(n=48 ,mean=c(32.5,135), sigma=sigmabadchoigung)
choigungbadsamples=data.frame(choigungbadsamples)
colnames(choigungbadsamples)=c("angle","velocity")
colMeans(choigungbadsamples)
var(choigungbadsamples)
choigungbadsamples['HIT_RESULT_NUM']=1


sigmaleejunghu=matrix(c(428,-135,-135,301), ncol=2)
leejunghusamples<- rmvnorm(n=700, mean=c(15.8,138), sigma=sigmaleejunghu)
leejunghusamples=data.frame(leejunghusamples)
colnames(leejunghusamples)=c("angle","velocity")
colMeans(leejunghusamples)
var(leejunghusamples)

sigmabadleejunghu<- matrix(c(551,-133,-133,253), ncol=2)
leejunghubadsamples<- rmvnorm(n=32 ,mean=c(14.3,136), sigma=sigmabadleejunghu)
leejunghubadsamples=data.frame(leejunghubadsamples)
colnames(leejunghubadsamples)=c("angle","velocity")
colMeans(leejunghubadsamples)
var(leejunghubadsamples)
leejunghubadsamples['HIT_RESULT_NUM']=1



sigmachaensung=matrix(c(623,-64.9,-64.9,361), ncol=2)
chaensungsamples<- rmvnorm(n=700, mean=c(19.1,140), sigma=sigmachaensung)
chaensungsamples=data.frame(chaensungsamples)
colnames(chaensungsamples)=c("angle","velocity")
colMeans(chaensungsamples)
var(chaensungsamples)

sigmabadchaensung <- matrix(c(808,33.3,33.3,331), ncol=2)
chaensungbadsamples<- rmvnorm(n=49 ,mean=c(23.6,131), sigma=sigmabadchaensung)
chaensungbadsamples=data.frame(chaensungbadsamples)
colnames(chaensungbadsamples)=c("angle","velocity")
colMeans(chaensungbadsamples)
var(chaensungbadsamples)
chaensungbadsamples['HIT_RESULT_NUM']=1

sigmakimjaehwan=matrix(c(514,27.3,27.3,362), ncol=2)
kimjaehwansamples<- rmvnorm(n=700, mean=c(17.3,145), sigma=sigmakimjaehwan)
kimjaehwansamples=data.frame(kimjaehwansamples)
colnames(kimjaehwansamples)=c("angle","velocity")
colMeans(kimjaehwansamples)
var(kimjaehwansamples)

sigmabadkimjaehwan <- matrix(c(592,112,112,302), ncol=2)
kimjaehwanbadsamples<- rmvnorm(n=68 ,mean=c(20.5,141), sigma=sigmabadkimjaehwan)
kimjaehwanbadsamples=data.frame(kimjaehwanbadsamples)
colnames(kimjaehwanbadsamples)=c("angle","velocity")
colMeans(kimjaehwanbadsamples)
var(kimjaehwanbadsamples)
kimjaehwanbadsamples['HIT_RESULT_NUM']=1


sigmajunjunwoo=matrix(c(584,-154,-154,381), ncol=2)
junjunwoosamples<- rmvnorm(n=700, mean=c(16.5,139), sigma=sigmajunjunwoo)
junjunwoonsamples=data.frame(junjunwoosamples)
colnames(junjunwoosamples)=c("angle","velocity")
colMeans(junjunwoosamples)
var(junjunwoosamples)

sigmabadjunjunwoo <- matrix(c(839,-281,-281,447), ncol=2)
junjunwoobadsamples<- rmvnorm(n=46 ,mean=c(22.5,132), sigma=sigmabadjunjunwoo)
junjunwoobadsamples=data.frame(junjunwoobadsamples)
colnames(junjunwoobadsamples)=c("angle","velocity")
colMeans(junjunwoobadsamples)
var(junjunwoobadsamples)
junjunwoobadsamples['HIT_RESULT_NUM']=1


sigmakimhyensu=matrix(c(535,-95.1,-95.1,312), ncol=2)
kimhyensusamples<- rmvnorm(n=700, mean=c(16.7,143), sigma=sigmakimhyensu)
kimhyensunsamples=data.frame(kimhyensusamples)
colnames(kimhyensusamples)=c("angle","velocity")
colMeans(kimhyensusamples)
var(kimhyensusamples)

sigmabadkimhyensu <- matrix(c(635,-128,-128,289), ncol=2)
kimhyensubadsamples<- rmvnorm(n=46 ,mean=c(19.2,140), sigma=sigmabadkimhyensu)
kimhyensubadsamples=data.frame(kimhyensubadsamples)
colnames(kimhyensubadsamples)=c("angle","velocity")
colMeans(kimhyensubadsamples)
var(kimhyensubadsamples)
kimhyensubadsamples['HIT_RESULT_NUM']=1


sigmaromack=matrix(c(699,-151,-151,352), ncol=2)
romacksamples<- rmvnorm(n=700, mean=c(22.6,141), sigma=sigmaromack)
romacksamples=data.frame(romacksamples)
colnames(romacksamples)=c("angle","velocity")
colMeans(romacksamples)
var(romacksamples)


sigmabadromack <- matrix(c(986,-163,-163,297), ncol=2)
romackbadsamples<- rmvnorm(n=72,mean=c(25.3,137), sigma=sigmabadromack)
romackbadsamples=data.frame(romackbadsamples)
colnames(romackbadsamples)=c("angle","velocity")
colMeans(romackbadsamples)
var(romackbadsamples)
romackbadsamples['HIT_RESULT_NUM']=1


#함수정의----------------------------------------------------------------------------------------------------------------
getindex=function(b0_1,b1_1,b2_1,b3_1,  #softmax 모델에, 공의 각도와 속도를 넣었을 때, bad인지, 혹은 몇루타인지 알려주는 함수이다. 
                 b0_2,b1_2,b2_2,b3_2,
                 b0_3,b1_3,b2_3,b3_3,
                 b0_4,b1_4,b2_4,b3_4,
                 ang_and_vel){
  mlog2=(b1_1*ang_and_vel[1])+(b2_1*ang_and_vel[2])+(b3_1*ang_and_vel[1]*ang_and_vel[2])+b0_1
  mlog3=(b1_2*ang_and_vel[1])+(b2_2*ang_and_vel[2])+(b3_2*ang_and_vel[1]*ang_and_vel[2])+b0_2
  mlog4=(b1_3*ang_and_vel[1])+(b2_3*ang_and_vel[2])+(b3_3*ang_and_vel[1]*ang_and_vel[2])+b0_3
  mlog5=(b1_4*ang_and_vel[1])+(b2_4*ang_and_vel[2])+(b3_4*ang_and_vel[1]*ang_and_vel[2])+b0_4
  
  pi_1=1
  pi_2=exp(mlog2)*pi_1
  pi_3=exp(mlog3)*pi_1
  pi_4= exp(mlog4)*pi_1
  pi_5=exp(mlog5)*pi_1
  
  
  
  proba1=pi_1/(pi_1+pi_2+pi_3+pi_4+pi_5)
  proba2=pi_2/(pi_1+pi_2+pi_3+pi_4+pi_5)
  proba3=pi_3/(pi_1+pi_2+pi_3+pi_4+pi_5)
  proba4=pi_4/(pi_1+pi_2+pi_3+pi_4+pi_5)
  proba5=pi_5/(pi_1+pi_2+pi_3+pi_4+pi_5)
  
  
  sample=runif(1,0,1)

  
  if (sample<=proba1){
    return("bad")
  }
  else if (sample>proba1&sample<=proba2+proba1){
    return("1ru")
  }
  else if (sample>(proba2+proba1)&sample<=(proba3+proba2+proba1)){
    return("2ru")
  }
  else if (sample>(proba3+proba2+proba1)&sample<=(proba4+proba3+proba2+proba1)){
    return("3ru")
  }
  else if (sample>(proba4+proba3+proba2+proba1)&sample<=(proba5+proba4+proba3+proba2+proba1)){
    return("homrun")
  
  }
}

getindex2=function(b0_1,b1_1,b2_1,b3_1,  #softmax 모델에, 공의 각도와 속도를 넣었을 때, bad인지, 혹은 몇루타인지 알려주는 함수이다. 
                  b0_2,b1_2,b2_2,b3_2,
                  b0_4,b1_4,b2_4,b3_4,
                  ang_and_vel){
  mlog2=(b1_1*ang_and_vel[1])+(b2_1*ang_and_vel[2])+(b3_1*ang_and_vel[1]*ang_and_vel[2])+b0_1
  mlog3=(b1_2*ang_and_vel[1])+(b2_2*ang_and_vel[2])+(b3_2*ang_and_vel[1]*ang_and_vel[2])+b0_2
  mlog5=(b1_4*ang_and_vel[1])+(b2_4*ang_and_vel[2])+(b3_4*ang_and_vel[1]*ang_and_vel[2])+b0_4
  
  pi_1=1
  pi_2=exp(mlog2)*pi_1
  pi_3=exp(mlog3)*pi_1
  pi_5=exp(mlog5)*pi_1
  
  
  
  proba1=pi_1/(pi_1+pi_2+pi_3+pi_5)
  proba2=pi_2/(pi_1+pi_2+pi_3+pi_5)
  proba3=pi_3/(pi_1+pi_2+pi_3+pi_5)
  proba5=pi_5/(pi_1+pi_2+pi_3+pi_5)
  
  
  sample=runif(1,0,1)
  
  
  if (sample<=proba1){
    return("bad")
  }
  else if (sample>proba1&sample<=proba2+proba1){
    return("1ru")
  }
  else if (sample>(proba2+proba1)&sample<=(proba3+proba2+proba1)){
    return("2ru")
  }
  else if (sample>(proba3+proba2+proba1)&sample<=(proba5+proba3+proba2+proba1)){
    return("homrun")
    
  }
}



getzangta=function(data){
  numbad=length(data[data$result=='bad',])
  num1=length(data[data$result=='1ru',])
  num2=length(data[data$result=='2ru',])
  num3=length(data[data$result=='3ru',])
  numhomrun=length(data[data$result=='homrun',])
 
  return((num1*1+num2*2+num3*3+numhomrun*4)/(numbad+num1+num2+num3+numhomrun))
}

mergeindex=function(sample){ #sampling된 공의 각도 속도들(200개~ 700개)에 getindex를 function을 적용하는 함수이다. 
  probe=c()
  for (i in 1:length(sample[,1])){
    a=getindex(-6.63, 0.114, 0.0475, -0.00104,
               -10.9, -0.125, 0.0616, 0.000907,
               -8.16,0.0355,0.0198,0.000203,
               -16.7, -0.28, 0.0783,0.00213,
               
               
      
              sample[i,])
    probe=rbind(probe,a)
  
  }
  return(probe)
}

mergeindex2=function(sample){ #sampling된 공의 각도 속도들(200개~ 700개)에 getindex를 function을 적용하는 함수이다. 
  probe=c()
  for (i in 1:length(sample[,1])){
    a=getindex2(-3.84, 0.0671, 0.0247, -0.00062,
                -4.76, -0.0694, 0.0202, 0.000495,
                -8.22, -0.0827, 0.0329,0.000466,
                
                
                sample[i,])
    probe=rbind(probe,a)
    
  }
  return(probe)
}




# 백호 
#-3.79, 0.0401, 0.0287, -0.000621,
#-7.55, -0.111, 0.0418, 0.000762,
#-8.52,0.0249,0.0248,-0.000171,
#-9.62, -0.141, 0.0364,0.00112,

#양의지
#-8.78, 0.12, 0.0537, -0.00112,
#-10.71, -0.119, 0.0585, 0.000776,
#-6.95,-0.0883,0.0233,0.000631,
#-15.7, -0.315, 0.0847,0.00245,





### 양의지  양의지  양의지  양의지  양의지  양의지  양의지  양의지  양의지  양의지  양의지  양의지  양의지 
yangresult=mergeindex(yangsamples)
yangresult=data.frame(yangresult)
colnames(yangresult)=c("result")
getzangta(yangresult)           #양의지 장타율 0.664 (21년) 0.603 (20년)




#-8.28, 0.12, 0.0537, -0.00112,
#-10.21, -0.119, 0.0585, 0.000776,
#-6.95,-0.0883,0.0233,0.000631,
#-15.7, -0.315, 0.0847,0.00245,

#0.7025





#강백호 강백호 강백호 강백호 강백호 강백호 강백호 강백호 강백호 강백호 강백호 강백호 강백호 강백호 
backhoresult=mergeindex(backhosamples)  #이 순서대로 선수마다의 결과를 얻을 수 있다. 
backhoresult=data.frame(backhoresult)
colnames(backhoresult)=c("result")
getzangta(backhoresult)         #강백호 장타율 0.579(21년) 0.544 (20년)

# 백호 
#-3.79, 0.0401, 0.0287, -0.000621,
#-7.55, -0.111, 0.0418, 0.000762,
#-8.52,0.0249,0.0248,-0.000171,
#-9.62, -0.141, 0.0364,0.00112,





### 박건우 박건우 박건우 박건우 박건우 박건우 박건우 박건우 박건우 박건우 박건우 박건우 박건우 박건우 
gunwooresult=mergeindex(gunwoosamples)
gunwooresult=data.frame(gunwooresult)
colnames(gunwooresult)=c("result")
getzangta(gunwooresult)


#-4.11, 0.0652, 0.025, -0.000661,
#-5.51, -0.0352, 0.0264, 0.000154,
#-9.92, -0.0299, 0.0323,0.000275,  

#0.438



### 최정 최정 최정 최정 최정 최정 최정 최정 최정 최정 최정 최정 최정 최정 최정 최정 
choigungresult=mergeindex2(choigungsamples)
choigungresult=data.frame(choigungresult)
colnames(choigungresult)=c("result")
getzangta(choigungresult)             

#-3.84, 0.0671, 0.0247, -0.00062,
#-4.76, -0.0694, 0.0202, 0.000495,
#-8.22, -0.0827, 0.0329,0.000466,


#0.5565


### 이정후  이정후  이정후  이정후  이정후  이정후  이정후  이정후  이정후  이정후  이정후  이정후 

leejunghuresult=mergeindex(leejunghusamples)
leejunghuresult=data.frame(leejunghuresult)
colnames(leejunghuresult)=c("result")
getzangta(leejunghuresult)               #비교대상: 장타율 0.503(21년) #0.524(20년)


#-4.81, 0.0637, 0.0264, -0.000699,
# -8.25, -0.133, 0.0447, 0.00112,
# -12.3,-0.28,0.0516,0.00215,
#-15.4, -0.583, 0.0641,0.0045,

#0.5142857       



### 채은성  채은성  채은성  채은성  채은성  채은성  채은성  채은성  채은성  채은성  채은성  채은성 
chaensungresult=mergeindex(chaensungsamples)
chaensungresult=data.frame(chaensungresult)
colnames(chaensungresult)=c("result")
getzangta(chaensungresult)               #비교대상: 장타율 0.533(21년) #0.452(20년)



#### 김재환  김재환  김재환  김재환  김재환  김재환  김재환  김재환  김재환  김재환  김재환  김재환  김재환  김재환 

kimjaehwanresult=mergeindex(kimjaehwansamples)
kimjaehwanresult=data.frame(kimjaehwanresult)
colnames(kimjaehwanresult)=c("result")
getzangta(kimjaehwanresult)     #비교대상 : 장타율 0.508 , 0.494 


#-5.77, 0.0332, 0.0264, -0.00123,
#-16.6, 0.123, 0.092, -0.000845,
#-7.95,0.0014,0.0225,0.000178,
#-16.2, -0.361, 0.0744,0.00258,

#0.4457





#### 전준우  전준우  전준우  전준우  전준우  전준우  전준우  전준우  전준우  전준우  전준우  전준우  전준우  전준우 
junjunwooresult=mergeindex(junjunwoosamples)
junjunwooresult=data.frame(junjunwooresult)
colnames(junjunwooresult)=c("result")
getzangta(junjunwooresult)  #비교대상 :  #0.447 #0.482

#-4.74, 0.0457, 0.0236, -0.000509,
#-8.82, -0.253, 0.044, 0.00169,
#-6.17,-0.00108,0.009,0.0000122,
#-15.1, -0.545, 0.0648,0.00413,

#0.4514





###김현수 김현수 김현수 김현수 김현수 김현수 김현수 김현수 김현수 김현수 김현수 김현수 김현수 김현수 김현수 김현수 김현수 
kimhyensuresult=mergeindex(kimhyensusamples)
kimhyensuresult=data.frame(kimhyensuresult)
colnames(kimhyensuresult)=c("result")
getzangta(kimhyensuresult)

#-2.69, 0.0439, 0.011, -0.000533,
#-12.8, -0.202, 0.0675, 0.00142,
#-8.49,-0.111,0.026,0.000857,
#-15.6, -0.412, 0.0698,0.00307,

#0.4428




###로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 로맥 
romackresult=mergeindex(romacksamples)
romackresult=data.frame(romackresult)
colnames(romackresult)=c("result")
getzangta(romackresult)    

#-2.57, -0.00165, 0.000844, -0.000212,
#-12.9, -0.0758, 0.0695, 0.000561,
#-22.3, -0.178, 0.12,0.00151,

#0.4614286  














