install.packages("readxl") 
library(readxl)


positionandteam2018=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_선수_2018.xlsm")
taza2018=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_타자 기본_2018.xlsm")
gong2018=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_HTS_2018.xls")

taza2019=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_타자 기본_2019.xls")
gong2019=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_HTS_2019.xls")

taza2020=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_타자 기본_2020.xls")
gong2020=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_HTS_2020.xls")


taza2021=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_타자 기본_2021.xls")
gong2021=read_excel("/Users/onehero/Downloads/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_데이터_210803/01_제공데이터/2021 빅콘테스트_데이터분석분야_챔피언리그_스포츠테크_HTS_2021.xls")


#-------------------------------------------------------------------------------------------------
gong2018$HIT_RESULT<-factor(gong2018$HIT_RESULT)
gong2019$HIT_RESULT<-factor(gong2019$HIT_RESULT)
gong2020$HIT_RESULT<-factor(gong2020$HIT_RESULT)
gong2021$HIT_RESULT<-factor(gong2021$HIT_RESULT)
gong2018$HIT_RESULT_NUM=c(0.5)
gong2018[gong2018$HIT_RESULT %in% c('땅볼아웃','플라이','병살타','직선타','파울플라이','인필드플라이'),]$HIT_RESULT_NUM=1
gong2018[gong2018$HIT_RESULT=='1루타',]$HIT_RESULT_NUM=2
gong2018[gong2018$HIT_RESULT=='내야안타(1루타)',]$HIT_RESULT_NUM=2
gong2018[gong2018$HIT_RESULT=='2루타',]$HIT_RESULT_NUM=3
gong2018[gong2018$HIT_RESULT=='3루타',]$HIT_RESULT_NUM=4
gong2018[gong2018$HIT_RESULT=='홈런',]$HIT_RESULT_NUM=5

gong2019$HIT_RESULT_NUM=c(0.5)
gong2019[gong2019$HIT_RESULT %in% c('땅볼아웃','플라이','병살타','직선타','파울플라이','인필드플라이'),]$HIT_RESULT_NUM=1
gong2019[gong2019$HIT_RESULT=='1루타',]$HIT_RESULT_NUM=2
gong2019[gong2019$HIT_RESULT=='내야안타(1루타)',]$HIT_RESULT_NUM=2
gong2019[gong2019$HIT_RESULT=='2루타',]$HIT_RESULT_NUM=3
gong2019[gong2019$HIT_RESULT=='3루타',]$HIT_RESULT_NUM=4
gong2019[gong2019$HIT_RESULT=='홈런',]$HIT_RESULT_NUM=5

gong2020$HIT_RESULT_NUM=c(0.5)
gong2020[gong2020$HIT_RESULT %in% c('땅볼아웃','플라이','병살타','직선타','파울플라이','인필드플라이'),]$HIT_RESULT_NUM=1
gong2020[gong2020$HIT_RESULT=='1루타',]$HIT_RESULT_NUM=2
gong2020[gong2020$HIT_RESULT=='내야안타(1루타)',]$HIT_RESULT_NUM=2
gong2020[gong2020$HIT_RESULT=='2루타',]$HIT_RESULT_NUM=3
gong2020[gong2020$HIT_RESULT=='3루타',]$HIT_RESULT_NUM=4
gong2020[gong2020$HIT_RESULT=='홈런',]$HIT_RESULT_NUM=5

gong2021$HIT_RESULT_NUM=c(0.5)
gong2021[gong2021$HIT_RESULT %in% c('땅볼아웃','플라이','병살타','직선타','파울플라이','인필드플라이'),]$HIT_RESULT_NUM=1
gong2021[gong2021$HIT_RESULT=='1루타',]$HIT_RESULT_NUM=2
gong2021[gong2021$HIT_RESULT=='내야안타(1루타)',]$HIT_RESULT_NUM=2
gong2021[gong2021$HIT_RESULT=='2루타',]$HIT_RESULT_NUM=3
gong2021[gong2021$HIT_RESULT=='3루타',]$HIT_RESULT_NUM=4
gong2021[gong2021$HIT_RESULT=='홈런',]$HIT_RESULT_NUM=5

gongdata=rbind(gong2020,gong2021)
gongdata=gongdata[gongdata$HIT_RESULT_NUM!=0.5,]
gongdata=data.frame(gongdata)


gongdata=cbind(gongdata$HIT_VEL,gongdata$HIT_ANG_VER,gongdata$HIT_RESULT_NUM)
gongdata=data.frame(gongdata)
colnames(gongdata)=c("HIT_VEL","HIT_ANG_VER","HIT_RESULT_NUM")



#----------------------------------------------------------------------------------------------------------------------------

#------------------------------------------------------------------------------------
yName = "HIT_RESULT_NUM" ; xName = c("HIT_ANG_VER","HIT_VEL","angvel")
fileNameRoot = "21,20데이터로 돌린 MCMC" 
numSavedSteps=5000 ; thinSteps=5
graphFileType = "png" 
#------------------------------------------------------------------------------- 
# 연도별 공데이터를 이용한 MCMC
source("Jags-Ynom-XmetMulti-Msoftmax.R")

mcmcCoda21_20 = genMCMC( data=gongdata21_20, xName=xName , yName=yName , 
                    numSavedSteps=numSavedSteps , thinSteps=thinSteps , 
                    saveName=fileNameRoot )




plotMCMC( mcmcCoda21_20 , data=gongdata21_20 , xName=xName , yName=yName , 
          pairsPlot=TRUE , showCurve=FALSE ,
          saveName=fileNameRoot , saveType=graphFileType )

summaryInfo = smryMCMC( mcmcCoda21_20 , 
                        saveName=fileNameRoot )
show(summaryInfo)

#------------------------------------------------------------------------------------------------
#선수별 MCMC 
#데이터 처리 

gongdata=rbind(gong2021)

gongdata$HIT_RESULT_NUM=c(0.5)
gongdata[gongdata$HIT_RESULT %in% c('땅볼아웃','플라이','병살타','직선타','파울플라이','번트아웃','인필드플라이','번트안타','삼중살타','야수선택'),]$HIT_RESULT_NUM=1
gongdata[gongdata$HIT_RESULT=='1루타',]$HIT_RESULT_NUM=2
gongdata[gongdata$HIT_RESULT=='내야안타(1루타)',]$HIT_RESULT_NUM=2
gongdata[gongdata$HIT_RESULT=='2루타',]$HIT_RESULT_NUM=3
gongdata[gongdata$HIT_RESULT=='3루타',]$HIT_RESULT_NUM=4
gongdata[gongdata$HIT_RESULT=='홈런',]$HIT_RESULT_NUM=5
gongdata$angvel=gongdata$HIT_VEL*gongdata$HIT_ANG_VER
gongdata=gongdata[gongdata$HIT_RESULT_NUM!=0.5,]
gongdata=data.frame(gongdata)
finalgongdata=data.frame(cbind(gongdata$HIT_ANG_VER,gongdata$HIT_VEL,gongdata$HIT_RESULT_NUM))
colnames(finalgongdata)=c("angle","velocity","HIT_RESULT_NUM")

finalgongdata=rbind(finalgongdata,yangbadsamples,backhobadsamples,gunwoobadsamples,choigungbadsamples,
                    leejunghubadsamples,chaensungbadsamples,kimjaehwanbadsamples,junjunwoobadsamples,
                    kimhyensubadsamples,romackbadsamples)


badgongdata=gongdata[gongdata$HIT_RESULT_NUM==1,]
yanggong=gongdata[gongdata$PCODE==76232,]#양의지
yanggong=data.frame(cbind(yanggong$HIT_ANG_VER,yanggong$HIT_VEL,yanggong$HIT_RESULT_NUM))
colnames(yanggong)=c("angle","velocity","HIT_RESULT_NUM")
yanggong['angvel']=yanggong$angle*yanggong$velocity
yangbadsamples['angvel']=yangbadsamples$angle*yangbadsamples$velocity
finalyanggong=rbind(yanggong,yangbadsamples)



backhogong=gongdata[gongdata$PCODE==68050,]# 강백호 
backhogong=data.frame(cbind(backhogong$HIT_ANG_VER,backhogong$HIT_VEL,backhogong$HIT_RESULT_NUM))
colnames(backhogong)=c("angle","velocity","HIT_RESULT_NUM")
backhogong['angvel']=backhogong$angle*backhogong$velocity
backhobadsamples['angvel']=backhobadsamples$angle*backhobadsamples$velocity
finalbackhogong=rbind(backhogong,backhobadsamples)

  
gunwoogong=gongdata[gongdata$PCODE==79215,]#박건우
gunwoogong=data.frame(cbind(gunwoogong$HIT_ANG_VER,gunwoogong$HIT_VEL,gunwoogong$HIT_RESULT_NUM))
colnames(gunwoogong)=c("angle","velocity","HIT_RESULT_NUM")
gunwoogong['angvel']=gunwoogong$angle*gunwoogong$velocity
gunwoobadsamples['angvel']=gunwoobadsamples$angle*gunwoobadsamples$velocity
finalgunwoogong=rbind(gunwoogong,gunwoobadsamples)
finalgunwoogong[finalgunwoogong$HIT_RESULT_NUM==5,]$HIT_RESULT_NUM=4


chaensunggong=gongdata[gongdata$PCODE==79192,] #채은성 

chaensunggong=data.frame(cbind(chaensunggong$HIT_ANG_VER,chaensunggong$HIT_VEL,chaensunggong$HIT_RESULT_NUM))
colnames(chaensunggong)=c("angle","velocity","HIT_RESULT_NUM")
chaensunggong['angvel']=chaensunggong$angle*chaensunggong$velocity
chaensungbadsamples['angvel']=chaensungbadsamples$angle*chaensungbadsamples$velocity
finalchaensunggong=rbind(chaensunggong,chaensungbadsamples)


choigunggong=gongdata[gongdata$PCODE==75847,]#최정 75847
choigunggong=data.frame(cbind(choigunggong$HIT_ANG_VER,choigunggong$HIT_VEL,choigunggong$HIT_RESULT_NUM))
colnames(choigunggong)=c("angle","velocity","HIT_RESULT_NUM")
choigunggong['angvel']=choigunggong$angle*choigunggong$velocity
choigungbadsamples['angvel']=choigungbadsamples$angle*choigungbadsamples$velocity
finalchoigunggong=rbind(gunwoogong,gunwoobadsamples)
finalchoigunggong[finalchoigunggong$HIT_RESULT_NUM==5,]$HIT_RESULT_NUM=4


leejunghugong=gongdata[gongdata$PCODE==67341 ,]#이정후 67341
leejunghugong=data.frame(cbind(leejunghugong$HIT_ANG_VER,leejunghugong$HIT_VEL,leejunghugong$HIT_RESULT_NUM))
colnames(leejunghugong)=c("angle","velocity","HIT_RESULT_NUM")
leejunghugong['angvel']=leejunghugong$angle*leejunghugong$velocity
leejunghubadsamples['angvel']=leejunghubadsamples$angle*leejunghubadsamples$velocity
finalleejunghugong=rbind(leejunghugong,leejunghubadsamples)



kimjaehwangong=gongdata[gongdata$PCODE==78224 ,]#김재환 78224
kimjaehwangong=data.frame(cbind(kimjaehwangong$HIT_ANG_VER,kimjaehwangong$HIT_VEL,kimjaehwangong$HIT_RESULT_NUM))
colnames(kimjaehwangong)=c("angle","velocity","HIT_RESULT_NUM")
kimjaehwangong['angvel']=kimjaehwangong$angle*kimjaehwangong$velocity
kimjaehwanbadsamples['angvel']=kimjaehwanbadsamples$angle*kimjaehwanbadsamples$velocity
finalkimjaehwangong=rbind(kimjaehwangong,kimjaehwanbadsamples)



junjunwoogong=gongdata[gongdata$PCODE== 78513 ,]#전준우 78513
junjunwoogong=data.frame(cbind(junjunwoogong$HIT_ANG_VER,junjunwoogong$HIT_VEL,junjunwoogong$HIT_RESULT_NUM))
colnames(junjunwoogong)=c("angle","velocity","HIT_RESULT_NUM")
junjunwoogong['angvel']=junjunwoogong$angle*junjunwoogong$velocity
junjunwoobadsamples['angvel']=junjunwoobadsamples$angle*junjunwoobadsamples$velocity
finaljunjunwoogong=rbind(junjunwoogong,junjunwoobadsamples)

kimhyensugong=gongdata[gongdata$PCODE==76290 ,]#김현수 76290
kimhyensugong=data.frame(cbind(kimhyensugong$HIT_ANG_VER,kimhyensugong$HIT_VEL,kimhyensugong$HIT_RESULT_NUM))
colnames(kimhyensugong)=c("angle","velocity","HIT_RESULT_NUM")
kimhyensugong['angvel']=kimhyensugong$angle*kimhyensugong$velocity
kimhyensubadsamples['angvel']=kimhyensubadsamples$angle*kimhyensubadsamples$velocity
finalkimhyensugong=rbind(kimhyensugong,kimhyensubadsamples)


romackgong=gongdata[gongdata$PCODE==67872 ,]#로맥 67872
romackgong=data.frame(cbind(romackgong$HIT_ANG_VER,romackgong$HIT_VEL,romackgong$HIT_RESULT_NUM))
colnames(romackgong)=c("angle","velocity","HIT_RESULT_NUM")
romackgong['angvel']=romackgong$angle*romackgong$velocity
romackbadsamples['angvel']=romackbadsamples$angle*romackbadsamples$velocity
finalromackgong[finalromackgong$HIT_RESULT_NUM==5,]$HIT_RESULT_NUM=4


yName = "HIT_RESULT_NUM" ; xName = c("angle","velocity","angvel")
fileNameRoot = "선수별 MCMC" 
numSavedSteps=5000 ; thinSteps=5
graphFileType = "png" 
#------------------------------------------------------------------------------- 
#선수별 공데이터를 이용한 MCMC
source("Jags-Ynom-XmetMulti-Msoftmax.R")

mcmcCoda = genMCMC( data=finalkimhyensugong, xName=xName , yName=yName , 
                         numSavedSteps=numSavedSteps , thinSteps=thinSteps , 
                         saveName=fileNameRoot )




plotMCMC( mcmcCoda , data=finalkimhyensugong , xName=xName , yName=yName , 
          pairsPlot=TRUE , showCurve=FALSE ,
          saveName=fileNameRoot , saveType=graphFileType )

summaryInfo = smryMCMC( mcmcCoda , 
                        saveName=fileNameRoot )
show(summaryInfo)






