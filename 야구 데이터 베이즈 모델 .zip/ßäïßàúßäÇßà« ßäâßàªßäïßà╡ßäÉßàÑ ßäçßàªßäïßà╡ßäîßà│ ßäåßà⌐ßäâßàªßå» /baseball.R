# Jags-Ydich-XnomSsubj-MbernBetaOmegaKappa.R 
# Accompanies the book:
#   Kruschke, J. K. (2014). Doing Bayesian Data Analysis: 
#   A Tutorial with R, JAGS, and Stan. 2nd Edition. Academic Press / Elsevier.
source("DBDA2E-utilities.R")
#===============================================================================

genMCMC = function( data , 
                    numSavedSteps=50000 , saveName=NULL , thinSteps=1 ) { 
  require(rjags)
  #-----------------------------------------------------------------------------
  # THE DATA.
  # N.B.: This function expects the data to be a data frame, 
  # with one component named y being a vector of integer 0,1 values,
  # and one component named s being a factor of subject identifiers.
  
  # ensures consecutive integer levels
  # Do some checking that data make sense:
  
  # Specify the data in a list, for later shipment to JAGS:
  dataList = 
    list(
      Ntotal=length(data$angle),   #어디가 어디가 어디가 어디가 어디가 어디가 어디가 어디가 어디가 어디가 어디가 어디
      y=data,                      #어디가 어디가 어디가 어디가 어디가 어디가 어디가 어디가 어디가 어디가 어디가 어디
      mean1=c(18.0878,141.943),     # <- 이것만 바꾸시오.  바꾸고 저장하는 거 잊지말기 
      x2=diag(2))                                      # 바꾸고 저장하는 거 잊지말기 
    
  
  #-----------------------------------------------------------------------------
  # THE MODEL.
  modelString = "
    model {
    for ( i in 1:Ntotal ) {
      y[i,1:2] ~ dmnorm(mu[1:2],tau[1:2,1:2])}
    tau[1:2,1:2]~dwish(x2[1:2, 1:2], 2)  #wishart distribution 

    vari=inverse(tau)
    
    mu[1:2]~dmnorm(mean1,x2[1:2, 1:2])
    
    }
     
  
  " # close quote for modelString
  writeLines( modelString , con="TEMPmodel.txt" )
  #-----------------------------------------------------------------------------
  
  #-----------------------------------------------------------------------------
  # RUN THE CHAINS
  parameters = c( "mu","vari") # The parameters to be monitored
  adaptSteps = 500             # Number of steps to adapt the samplers
  burnInSteps = 500            # Number of steps to burn-in the chains
  nChains = 4                  # nChains should be 2 or more for diagnostics 
  nIter = ceiling( ( numSavedSteps * thinSteps ) / nChains )
  # Create, initialize, and adapt the model:
  jagsModel = jags.model( "TEMPmodel.txt" , data=dataList , #inits=initsList , 
                          n.chains=nChains , n.adapt=adaptSteps )
  # Burn-in:
  cat( "Burning in the MCMC chain...\n" )
  update( jagsModel , n.iter=burnInSteps )
  # The saved MCMC chain:
  cat( "Sampling final MCMC chain...\n" )
  codaSamples = coda.samples( jagsModel , variable.names=parameters , 
                              n.iter=nIter , thin=thinSteps )
  # resulting codaSamples object has these indices: 
  #   codaSamples[[ chainIdx ]][ stepIdx , paramIdx ]
  if ( !is.null(saveName) ) {
    save( codaSamples , file=paste(saveName,"Mcmc.Rdata",sep="") )
  }
  return( codaSamples )
} # end function

#===============================================================================

smryMCMC = function(  codaSamples , compVal=0.5 , rope=NULL , 
                      diffIdVec=NULL , compValDiff=0.0 , ropeDiff=NULL , 
                      saveName=NULL ) {
  mcmcMat = as.matrix(codaSamples,chains=TRUE)
  Ntheta = length(grep("theta",colnames(mcmcMat)))
  summaryInfo = NULL
  rowIdx = 0
  # overall omega:
  summaryInfo = rbind( summaryInfo , 
                       summarizePost( mcmcMat[,"omega"] ,
                                      compVal=compVal , ROPE=rope ) )
  rowIdx = rowIdx+1
  rownames(summaryInfo)[rowIdx] = "omega"
  # kappa:
  summaryInfo = rbind( summaryInfo , 
                       summarizePost( mcmcMat[,"kappa"] ,
                                      compVal=NULL , ROPE=NULL ) )
  rowIdx = rowIdx+1
  rownames(summaryInfo)[rowIdx] = "kappa"
  # individual theta's:
  for ( tIdx in 1:Ntheta ) {
    parName = paste0("theta[",tIdx,"]")
    summaryInfo = rbind( summaryInfo , 
                         summarizePost( mcmcMat[,parName] , compVal=compVal , ROPE=rope ) )
    rowIdx = rowIdx+1
    rownames(summaryInfo)[rowIdx] = parName
  }
  # differences of individual theta's:
  if ( !is.null(diffIdVec) ) {
    Nidx = length(diffIdVec)
    for ( t1Idx in 1:(Nidx-1) ) {
      for ( t2Idx in (t1Idx+1):Nidx ) {
        parName1 = paste0("theta[",diffIdVec[t1Idx],"]")
        parName2 = paste0("theta[",diffIdVec[t2Idx],"]")
        summaryInfo = rbind( summaryInfo , 
                             summarizePost( mcmcMat[,parName1]-mcmcMat[,parName2] ,
                                            compVal=compValDiff , ROPE=ropeDiff ) )
        rowIdx = rowIdx+1
        rownames(summaryInfo)[rowIdx] = paste0(parName1,"-",parName2)
      }
    }
  }
  # save:
  if ( !is.null(saveName) ) {
    write.csv( summaryInfo , file=paste(saveName,"SummaryInfo.csv",sep="") )
  }
  show( summaryInfo )
  return( summaryInfo )
}

#===============================================================================

plotMCMC = function( codaSamples , data , 
                      rope=NULL , 
                     diffIdVec=NULL , compValDiff=0.0 , ropeDiff=NULL , 
                     saveName=NULL , saveType="jpg" ) {
  #-----------------------------------------------------------------------------
  # N.B.: This function expects the data to be a data frame, 
  # with one component named y being a vector of integer 0,1 values,
  # and one component named s being a factor of subject identifiers.
  y = data
  #s = as.numeric(data[,sName]) # ensures consecutive integer levels
  # Now plot the posterior:
  mcmcMat = as.matrix(codaSamples,chains=TRUE)
  chainLength = NROW( mcmcMat )
  # Plot omega, kappa:
  openGraph(width=3.5*2,height=3.0)
  par( mfrow=c(3,2) )
  par( mar=c(3.5,3,1,1) , mgp=c(2.0,0.7,0) )
  postInfo = plotPost( mcmcMat[,"mu[1]"] , compVal=NULL , ROPE=NULL ,
                       xlab=bquote("mu[1]") , main="Group Mode" , 
                       xlim=c( min(mcmcMat[,"mu[1]"]),
                               quantile(mcmcMat[,"mu[1]"],probs=c(0.990)) ) )
  postInfo = plotPost( mcmcMat[,"mu[2]"] , compVal=NULL , ROPE=rope ,
                       xlab="mu[2]" , main="Group Mode" ,
                       xlim=quantile(mcmcMat[,"mu[2]"],probs=c(0.005,0.995)) )
  postInfo = plotPost( mcmcMat[,"vari[1,1]"] , compVal=NULL , ROPE=rope ,
                       xlab="variation[1,1]" , main="Group Mode" ,
                       xlim=quantile(mcmcMat[,"vari[1,1]"],probs=c(0.005,0.995)) )
  postInfo = plotPost( mcmcMat[,"vari[1,2]"] , compVal=NULL , ROPE=rope ,
                       xlab="variation[1,2]" , main="Group Mode" ,
                       xlim=quantile(mcmcMat[,"vari[1,2]"],probs=c(0.005,0.995)) )
  postInfo = plotPost( mcmcMat[,"vari[2,1]"] , compVal=NULL , ROPE=rope ,
                       xlab="variation[2,1]" , main="Group Mode" ,
                       xlim=quantile(mcmcMat[,"vari[2,1]"],probs=c(0.005,0.995)) )
  postInfo = plotPost( mcmcMat[,"vari[2,2]"] , compVal=NULL , ROPE=rope ,
                       xlab="variation[2,2]" , main="Group Mode" ,
                       xlim=quantile(mcmcMat[,"vari[2,2]"],probs=c(0.005,0.995)) )}
  
 
  
  
 

#===============================================================================
